from distutils.core import setup
setup(
    name='biostuff',
    version='0.1dev',
    author='Ozge Yoluk',
    author_email='ozge.yoluk@scilifelab.se',
    url='example.com',
    packages=['biostuff',],
    license='GPLv3',
    long_description=open('README.txt').read(),
)
